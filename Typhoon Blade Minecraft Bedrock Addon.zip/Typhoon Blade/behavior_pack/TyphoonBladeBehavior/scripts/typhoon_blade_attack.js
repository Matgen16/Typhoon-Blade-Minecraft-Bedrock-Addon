let typhoonBladeItem = "fortnite:typhoon_blade";
let attackPower = 10;
let attackRange = 2;

function damageBlocksInFront(player) {
    let direction = player.getRotation();
    let position = player.location;

    let directionVector = {
        x: Math.cos(direction.y),
        y: 0,
        z: Math.sin(direction.y)
    };

    for (let i = 1; i <= attackRange; i++) {
        let blockPos = position.add(directionVector.x * i, directionVector.y * i, directionVector.z * i);
        let block = world.getBlock(blockPos);

        if (block) {
            block.damaging(attackPower);
        }
    }
}

world.events.itemUse.subscribe((eventData) => {
    let player = eventData.source;
    if (eventData.itemStack.id === typhoonBladeItem) {
        damageBlocksInFront(player);
    }
});
