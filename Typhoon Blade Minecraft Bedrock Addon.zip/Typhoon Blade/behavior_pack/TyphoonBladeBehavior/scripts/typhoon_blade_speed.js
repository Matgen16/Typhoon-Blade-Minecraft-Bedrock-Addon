let typhoonBladeItem = "fortnite:typhoon_blade";
let speedEffect = "minecraft:speed";
let speedLevel = 2;

function applySpeedEffect(player) {
    player.addEffect(speedEffect, 100, speedLevel, false);
}

world.events.tick.subscribe(() => {
    let players = world.getPlayers();
    players.forEach((player) => {
        if (player.isSprinting && player.getInventory().contains(typhoonBladeItem)) {
            applySpeedEffect(player);
        }
    });
});
